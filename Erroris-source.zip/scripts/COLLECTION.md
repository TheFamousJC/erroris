# Digital error collection

The active catalogue is data/catalogue.json. Each record stores a code, aliases, context, provider, plain-language meaning, scope, likely investigation area, source links and review date. The user plan contains steps, difficulty, required access, impact and escalation advice. Website-owner plans are separate and must not be shown as visitor instructions.

Use Google/Mozilla browser support, Microsoft consumer/technical documentation and MDN or standards documentation as primary references. Community discussions can identify leads; they are not automatically verified resolutions. Check software context and version applicability before importing a guide. Never turn a generic system-code definition into a product-specific repair claim.

Run node scripts/build-catalogue.cjs and node scripts/test-catalogue.cjs before publishing dist. Full source and scripts are bundled in Erroris-source.zip. The previous appliance research is in the separate local archive outputs/Erroris-before-computer-focus.zip.

The bounded collector remains available: node scripts/collect-sources.cjs --limit 10 --depth 0. It checks robots.txt, limits requests, caches documents and emits unreviewed candidates in ../work/source-cache. It does not modify the reviewed catalogue. Local HTTP fetch is blocked by DNS here; current guides were assembled through web-assisted review. Its generic table/heading parser may miss browser phrases and hexadecimal values; treat all candidates as leads, and use a source-specific adapter before bulk imports. PDF files are queued for manual review.

The site does not automatically search, browse, execute commands, inspect a device, check outages, or send support messages. External Google/YouTube links are clearly labelled. New collection must preserve that distinction.
