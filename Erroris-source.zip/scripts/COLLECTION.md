# Manufacturer collection

`data/catalogue.json` is the reviewed publication dataset. `data/sources.json` registers official source URLs, regions and scopes. The first broad import was extracted through web search/page tools and editorially reduced to short definitions. It was not produced by a successful unattended full-site crawl.

Run `node scripts/collect-sources.cjs --limit 25 --depth 0` to fetch registered pages. Add `--brand Whirlpool` to narrow it. `--depth 1` follows relevant same-origin links within the document budget. Run from the project folder. Cached original pages/PDFs and candidate reports go to `../work/source-cache`, outside the published dist folder. Reports keep fetch failures and rate limits visible.

The collector checks robots.txt, waits between requests, restricts hosts to the registered list, caps response size and document count, uses conditional requests, and stops a host on access/rate-limit responses. Unavailable robots information fails closed. It does not bypass login, bot challenges or access controls. PDF downloads stay queued for model-aware manual review; no PDF code extraction is claimed.

For a downloaded HTML document: `node scripts/collect-sources.cjs --offline-file ../work/page.html --source whirlpool-front`. This extracts candidate table rows/headings without network access. Candidate evidence is untrusted, may contain navigation noise or non-code numbers, and never changes the reviewed catalogue.

Review each candidate against the original official page: brand, device, region, exact code, definition and model applicability. Add only validated definitions to catalogue.json with `kind: reference`, `score: null`, `reviewStatus: definition-reviewed`. Never derive a repair procedure or DIY score from a code table alone. Upgrade to `kind: guide` only after separately reviewing the procedure. Preserve disagreements as separate model-scoped records.

Run `node scripts/build-catalogue.cjs` to validate and emit dist/catalogue.js. Run `node scripts/test-collector.cjs` and `node scripts/test-catalogue.cjs` before publication. Publish only dist; do not publish cached source copies or unreviewed candidate evidence.

Next source discovery targets (not imported): Beko, Candy and NEFF. No entry should be counted simply because a support landing page or brand domain exists. Existing import focuses on laundry, dishwashers and printers; broad car/computer coverage is still future work.
